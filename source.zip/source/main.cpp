#include <iostream>
#include <vector>
#include <cstdint>
#include <fstream>
#include <string>
#include <sstream>
#include <thread> 
#include <chrono> 
#include <cstdlib> 
#include <ctime>   
#include <map>

const uint8_t OP_SET        = 0x01;
const uint8_t OP_ADD        = 0x02;
const uint8_t OP_PRINT      = 0x03;
const uint8_t OP_SUB        = 0x04;
const uint8_t OP_MUL        = 0x05;
const uint8_t OP_JUMP       = 0x06;
const uint8_t OP_JZ         = 0x07; // Upgraded: JIF is now JZ
const uint8_t OP_LOOP       = 0x08;
const uint8_t OP_DIV        = 0x0F; 
const uint8_t OP_PRINT_CHAR = 0x0A;
const uint8_t OP_CLEAR      = 0x0B; 
const uint8_t OP_INPUT      = 0x0C; 
const uint8_t OP_RANDOM     = 0x0D; 
const uint8_t OP_CMP        = 0x0E; 
const uint8_t OP_STORE      = 0x10; 
const uint8_t OP_LOAD       = 0x11; 
const uint8_t OP_INPUT_CHAR = 0x12; 
const uint8_t OP_CMP_STR    = 0x13; 
const uint8_t OP_INPUT_STR  = 0x14; 
const uint8_t OP_PUSH       = 0x15; 
const uint8_t OP_POP        = 0x16; 
const uint8_t OP_CALL       = 0x17; 
const uint8_t OP_RET        = 0x18; 
const uint8_t OP_AND        = 0x19; 
const uint8_t OP_OR         = 0x1A; 
const uint8_t OP_XOR        = 0x1B; 
const uint8_t OP_SHL        = 0x1C; 
const uint8_t OP_SHR        = 0x1D; 
const uint8_t OP_NOT        = 0x1E; 
const uint8_t OP_MOD        = 0x1F; 
const uint8_t OP_SET_MODE   = 0x20; 
const uint8_t OP_LD         = 0x21; 
const uint8_t OP_ST         = 0x22; 
const uint8_t OP_JNZ        = 0x23; // New: Jump if Not Zero
const uint8_t OP_JS         = 0x24; // New: Jump if Sign (Negative)
const uint8_t OP_ADDI       = 0x25; // New: Add Immediate
const uint8_t OP_SUBI       = 0x26; // New: Subtract Immediate
const uint8_t OP_HALT       = 0xFF;

int main(int argc, char* argv[]) {
    std::srand(std::time(nullptr));

    if (argc < 2) {
        std::cerr << "Usage: " << argv[0] << " <program.bin>" << std::endl;
        return 1;
    }

    std::string filename = argv[1];

    if (filename.length() < 4 || filename.substr(filename.length() - 4) != ".bin") {
        std::cerr << "Error: File must have a .bin extension!" << std::endl;
        return 1;
    }

    std::ifstream file(filename);
    if (!file.is_open()) {
        std::cerr << "Error: Could not open file " << filename << std::endl;
        return 1;
    }

    std::vector<std::string> tokens;
    std::string token;
    while (file >> token) {
        tokens.push_back(token);
    }
    file.close();

    std::map<std::string, uint32_t> labels;
    std::vector<std::string> clean_tokens;
    uint32_t current_word_address = 0;

    for (const auto& t : tokens) {
        if (t.back() == ':') {
            std::string label_name = t.substr(0, t.length() - 1);
            labels[label_name] = current_word_address;
        } else {
            clean_tokens.push_back(t);
            current_word_address++;
        }
    }

    std::vector<uint32_t> memory;
    for (const auto& t : clean_tokens) {
        if (labels.find(t) != labels.end()) {
            memory.push_back(labels[t]); 
        } else {
            uint32_t word_val;
            std::stringstream ss;
            ss << std::hex << t;
            if (ss >> word_val) {
                memory.push_back(word_val);
            } else {
                std::cerr << "Error: Unknown token/label '" << t << "'" << std::endl;
                return 1;
            }
        }
    }

    std::vector<uint32_t> registers(8, 0); 
    std::vector<uint32_t> ram(1024, 0);    
    std::vector<uint32_t> stack(64, 0);    
    uint8_t sp = 0;                       
    uint32_t pc = 0;                      
    bool running = true;
    uint8_t bit_mode = 0; 

    bool ZF = false;
    bool SF = false;

    std::cout << "--- Starting Advanced Dynamic 32-bit CPU ---" << std::endl;

    while (running && pc < memory.size()) {
        uint32_t opcode = memory[pc++];

        auto check_memory = [&](size_t needed_words) -> bool {
            if (pc + needed_words > memory.size()) {
                std::cerr << "Error: Segmentation fault! Out of memory at PC " << (pc - 1) << std::endl;
                running = false;
                return false;
            }
            return true;
        };

        auto apply_mode = [&](uint64_t value) -> uint32_t {
            if (bit_mode == 0) return static_cast<uint32_t>(value & 0xFF); 
            if (bit_mode == 1) return static_cast<uint32_t>(value & 0xFFFF); 
            return static_cast<uint32_t>(value & 0xFFFFFFFF); 
        };

        auto update_flags = [&](uint32_t result, bool is_negative = false) {
            ZF = (result == 0);
            SF = is_negative;
        };

        switch (opcode) {
            case OP_SET: {
                if (!check_memory(2)) break;
                uint32_t reg = memory[pc++];
                uint32_t val = memory[pc++];
                registers[reg] = apply_mode(val);
                break;
            }
            case OP_ADD: {
                if (!check_memory(3)) break;
                uint32_t dest = memory[pc++];
                uint32_t src1 = memory[pc++];
                uint32_t src2 = memory[pc++];
                uint64_t raw_res = static_cast<uint64_t>(registers[src1]) + registers[src2];
                registers[dest] = apply_mode(raw_res);
                update_flags(registers[dest]);
                break;
            }
            case OP_SUB: {
                if (!check_memory(3)) break;
                uint32_t dest = memory[pc++];
                uint32_t src1 = memory[pc++];
                uint32_t src2 = memory[pc++];
                bool is_neg = registers[src1] < registers[src2];
                registers[dest] = apply_mode(static_cast<uint64_t>(registers[src1]) - registers[src2]);
                update_flags(registers[dest], is_neg);
                break;
            }
            case OP_MUL: {
                if (!check_memory(3)) break;
                uint32_t dest = memory[pc++];
                uint32_t src1 = memory[pc++];
                uint32_t src2 = memory[pc++];
                registers[dest] = apply_mode(static_cast<uint64_t>(registers[src1]) * registers[src2]);
                update_flags(registers[dest]);
                break;
            }
            case OP_DIV: { 
                if (!check_memory(3)) break;
                uint32_t dest = memory[pc++];
                uint32_t src1 = memory[pc++];
                uint32_t src2 = memory[pc++];
                if (registers[src2] == 0) {
                    std::cerr << "Hardware Error: Division by Zero!" << std::endl;
                    running = false;
                } else {
                    registers[dest] = apply_mode(registers[src1] / registers[src2]);
                    update_flags(registers[dest]);
                }
                break;
            }
            case OP_ADDI: {
                if (!check_memory(3)) break;
                uint32_t dest = memory[pc++];
                uint32_t src = memory[pc++];
                uint32_t imm = memory[pc++];
                uint64_t raw_res = static_cast<uint64_t>(registers[src]) + imm;
                registers[dest] = apply_mode(raw_res);
                update_flags(registers[dest]);
                break;
            }
            case OP_SUBI: {
                if (!check_memory(3)) break;
                uint32_t dest = memory[pc++];
                uint32_t src = memory[pc++];
                uint32_t imm = memory[pc++];
                bool is_neg = registers[src] < imm;
                registers[dest] = apply_mode(static_cast<uint64_t>(registers[src]) - imm);
                update_flags(registers[dest], is_neg);
                break;
            }
            case OP_SET_MODE: { 
                if (!check_memory(1)) break;
                bit_mode = static_cast<uint8_t>(memory[pc++]);
                std::cout << "[CPU] Switched to " << (bit_mode == 0 ? "8-bit" : (bit_mode == 1 ? "16-bit" : "32-bit")) << " mode" << std::endl;
                break;
            }
            case OP_JUMP: {
                if (!check_memory(1)) break;
                uint32_t target_pc = memory[pc++];
                pc = target_pc;
                break;
            }
            case OP_JZ: {
                if (!check_memory(1)) break;
                uint32_t target_pc = memory[pc++];
                if (ZF) {
                    pc = target_pc;
                }
                break;
            }
            case OP_JNZ: {
                if (!check_memory(1)) break;
                uint32_t target_pc = memory[pc++];
                if (!ZF) {
                    pc = target_pc;
                }
                break;
            }
            case OP_JS: {
                if (!check_memory(1)) break;
                uint32_t target_pc = memory[pc++];
                if (SF) {
                    pc = target_pc;
                }
                break;
            }
            case OP_LOOP: {
                if (!check_memory(2)) break;
                uint32_t reg = memory[pc++];
                uint32_t target_pc = memory[pc++];
                std::this_thread::sleep_for(std::chrono::milliseconds(150));
                registers[reg] = apply_mode(registers[reg] - 1); 
                update_flags(registers[reg]);
                if (registers[reg] != 0) {
                    pc = target_pc; 
                }
                break;
            }
            case OP_PRINT: {
                if (!check_memory(1)) break;
                uint32_t reg = memory[pc++];
                std::cout << "Register R" << (int)reg << " = " << registers[reg] << std::endl;
                break;
            }
            case OP_PRINT_CHAR: {
                if (!check_memory(1)) break;
                uint32_t reg = memory[pc++];
                std::cout << (char)registers[reg]; 
                std::cout.flush(); 
                break;
            }
            case OP_CLEAR: { 
                std::system("cls"); 
                break;
            }
            case OP_INPUT: { 
                if (!check_memory(1)) break;
                uint32_t reg = memory[pc++];
                uint32_t user_val;
                std::cout << "Enter a number for R" << (int)reg << ": ";
                if (std::cin >> user_val) {
                    registers[reg] = apply_mode(user_val);
                }
                break;
            }
            case OP_RANDOM: { 
                if (!check_memory(1)) break;
                uint32_t reg = memory[pc++];
                registers[reg] = apply_mode((std::rand() % 100) + 1);
                break;
            }
            case OP_CMP: { 
                if (!check_memory(3)) break;
                uint32_t dest = memory[pc++];
                uint32_t src1 = memory[pc++];
                uint32_t src2 = memory[pc++];
                if (registers[src1] == registers[src2]) registers[dest] = 0;
                else if (registers[src1] > registers[src2]) registers[dest] = 1;
                else registers[dest] = 2;
                break;
            }
            case OP_STORE: { 
                if (!check_memory(2)) break;
                uint32_t addr_reg = memory[pc++];
                uint32_t data_reg = memory[pc++];
                if (registers[addr_reg] < ram.size()) {
                    ram[registers[addr_reg]] = registers[data_reg]; 
                } else {
                    std::cerr << "Hardware Error: RAM address out of bounds!" << std::endl;
                    running = false;
                }
                break;
            }
            case OP_LOAD: { 
                if (!check_memory(2)) break;
                uint32_t dest_reg = memory[pc++];
                uint32_t addr_reg = memory[pc++];
                if (registers[addr_reg] < ram.size()) {
                    registers[dest_reg] = ram[registers[addr_reg]]; 
                } else {
                    std::cerr << "Hardware Error: RAM address out of bounds!" << std::endl;
                    running = false;
                }
                break;
            }
            case OP_LD: { 
                if (!check_memory(2)) break;
                uint32_t dest_reg = memory[pc++];
                uint32_t target_addr = memory[pc++];
                if (target_addr < ram.size()) {
                    registers[dest_reg] = ram[target_addr];
                } else {
                    std::cerr << "Hardware Error: RAM address out of bounds on LD!" << std::endl;
                    running = false;
                }
                break;
            }
            case OP_ST: { 
                if (!check_memory(2)) break;
                uint32_t target_addr = memory[pc++];
                uint32_t src_reg = memory[pc++];
                if (target_addr < ram.size()) {
                    ram[target_addr] = registers[src_reg];
                } else {
                    std::cerr << "Hardware Error: RAM address out of bounds on ST!" << std::endl;
                    running = false;
                }
                break;
            }
            case OP_INPUT_CHAR: { 
                if (!check_memory(1)) break;
                uint32_t reg = memory[pc++];
                char user_char;
                std::cout << "Enter a character: ";
                if (std::cin >> user_char) {
                    registers[reg] = apply_mode(user_char);
                }
                break;
            }
            case OP_CMP_STR: { 
                if (!check_memory(3)) break;
                uint32_t dest_reg = memory[pc++];
                uint32_t addr_reg1 = memory[pc++];
                uint32_t addr_reg2 = memory[pc++];
                uint32_t addr1 = registers[addr_reg1];
                uint32_t addr2 = registers[addr_reg2];
                bool match = true;
                while (addr1 < ram.size() && addr2 < ram.size()) {
                    if (ram[addr1] != ram[addr2]) { match = false; break; }
                    if (ram[addr1] == 0 || ram[addr2] == 0) break;
                    addr1++; addr2++;
                }
                registers[dest_reg] = match ? 0 : 1;
                break;
            }
            case OP_INPUT_STR: { 
                if (!check_memory(1)) break;
                uint32_t addr_reg = memory[pc++];
                uint32_t start_addr = registers[addr_reg];
                std::string user_str;
                std::cout << "Input string: ";
                std::cin >> user_str;
                for (char c : user_str) {
                    if (start_addr >= ram.size() - 1) break;
                    ram[start_addr++] = apply_mode(c);
                }
                ram[start_addr] = 0;
                break;
            }
            case OP_PUSH: { 
                if (!check_memory(1)) break;
                uint32_t reg = memory[pc++];
                if (sp >= stack.size()) {
                    std::cerr << "Hardware Error: Stack Overflow!" << std::endl;
                    running = false;
                } else {
                    stack[sp++] = registers[reg];
                }
                break;
            }
            case OP_CALL: { 
                if (!check_memory(1)) break;
                uint32_t target_pc = memory[pc++];
                if (sp >= stack.size()) {
                    std::cerr << "Hardware Error: Stack Overflow on CALL!" << std::endl;
                    running = false;
                } else {
                    stack[sp++] = pc;
                    pc = target_pc;
                }
                break;
            }
            case OP_RET: { 
                if (sp == 0) {
                    std::cerr << "Hardware Error: Stack Underflow on RET!" << std::endl;
                    running = false;
                } else {
                    pc = stack[--sp];
                }
                break;
            }
            case OP_POP: { 
                if (!check_memory(1)) break;
                uint32_t reg = memory[pc++];
                if (sp == 0) {
                    std::cerr << "Hardware Error: Stack Underflow!" << std::endl;
                    running = false;
                } else {
                    registers[reg] = stack[--sp];
                }
                break;
            }
            case OP_AND: { 
                if (!check_memory(3)) break;
                uint32_t dest = memory[pc++];
                uint32_t src1 = memory[pc++];
                uint32_t src2 = memory[pc++];
                registers[dest] = apply_mode(registers[src1] & registers[src2]);
                update_flags(registers[dest]);
                break;
            }
            case OP_OR: { 
                if (!check_memory(3)) break;
                uint32_t dest = memory[pc++];
                uint32_t src1 = memory[pc++];
                uint32_t src2 = memory[pc++];
                registers[dest] = apply_mode(registers[src1] | registers[src2]);
                update_flags(registers[dest]);
                break;
            }
            case OP_XOR: { 
                if (!check_memory(3)) break;
                uint32_t dest = memory[pc++];
                uint32_t src1 = memory[pc++];
                uint32_t src2 = memory[pc++];
                registers[dest] = apply_mode(registers[src1] ^ registers[src2]);
                update_flags(registers[dest]);
                break;
            }
            case OP_SHL: { 
                if (!check_memory(3)) break;
                uint32_t dest = memory[pc++];
                uint32_t src1 = memory[pc++];
                uint32_t shift_reg = memory[pc++];
                registers[dest] = apply_mode(registers[src1] << registers[shift_reg]);
                update_flags(registers[dest]);
                break;
            }
            case OP_SHR: { 
                if (!check_memory(3)) break;
                uint32_t dest = memory[pc++];
                uint32_t src1 = memory[pc++];
                uint32_t shift_reg = memory[pc++];
                registers[dest] = apply_mode(registers[src1] >> registers[shift_reg]);
                update_flags(registers[dest]);
                break;
            }
            case OP_NOT: { 
                if (!check_memory(2)) break;
                uint32_t dest = memory[pc++];
                uint32_t src = memory[pc++];
                registers[dest] = apply_mode(~registers[src]);
                update_flags(registers[dest]);
                break;
            }
            case OP_MOD: { 
                if (!check_memory(3)) break;
                uint32_t dest = memory[pc++];
                uint32_t src1 = memory[pc++];
                uint32_t src2 = memory[pc++];
                if (registers[src2] == 0) {
                    std::cerr << "Hardware Error: Modulo by Zero!" << std::endl;
                    running = false;
                } else {
                    registers[dest] = apply_mode(registers[src1] % registers[src2]);
                    update_flags(registers[dest]);
                }
                break;
            }
            case OP_HALT:
                running = false;
                break;
            default:
                std::cerr << "Unknown opcode: 0x" << std::hex << (int)opcode << " at PC " << (pc - 1) << std::endl;
                running = false;
                break;
        }
    }

    std::cout << "\n--- Program Finished ---" << std::endl;
    return 0;
}